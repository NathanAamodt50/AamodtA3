﻿/********************************************************************
*** NAME : Nathan Aamodt                                          ***
*** CLASS : CSC 346                                               ***
*** ASSIGNMENT : AamodtA3 - Assign 3                              ***
*** DUE DATE : Febuary 26th 2021                                  ***
*** INSTRUCTOR : GAMRADT                                          ***
*********************************************************************
*** DESCRIPTION : This Assignment is creating 2 players in a game ***
*** one using defult constructor then anouther using values passed***
*** in from the Program.cs file, this allows 2 differnt types of  ***
*** players/characters in this game.                              ***
********************************************************************/
using System;
using System.Collections.Generic;
using System.Text;

namespace HeroNS
{
    public class View
    {
        /********************************************************************
        *** METHOD void VeiwH                                             ***
        *********************************************************************
        *** DESCRIPTION : This prints the characters stats Horizontaly    ***
        *** INPUT ARGS : Name,Race,Health,Protection, and Weapon.         ***
        *** OUTPUT ARGS: NONE                                             ***
        *** IN/OUT ARGS : NONE                                            ***
        *** RETURN : NONE                                                 ***
        ********************************************************************/
        public static void ViewH(string Name,Global.RaceType Race,int Health,int Protection,Global.WeaponType Weapon)
        {
            Console.WriteLine("Name \t Race \t Health  Protection  Weapon");
            Console.WriteLine(Name+"\t "+ Race +"    " + Health+"        "+ Protection + "      " + Weapon);
        }
        /********************************************************************
        *** METHOD void VeiwV                                             ***
        *********************************************************************
        *** DESCRIPTION : This prints the characters stats Verticaly      ***
        *** INPUT ARGS : Name,Race,Health,Protection, and Weapon.         ***
        *** OUTPUT ARGS: NONE                                             ***
        *** IN/OUT ARGS : NONE                                            ***
        *** RETURN : NONE                                                 ***
        ********************************************************************/
        public static void ViewV(string Name, Global.RaceType Race,int Health,int Protection, Global.WeaponType Weapon)
        {
            Console.WriteLine("\n\nName: "+Name);
            Console.WriteLine("\nRace: "+Race);
            Console.WriteLine("\nHealth: " + Health);
            Console.WriteLine("\nProtection: "+Protection);
            Console.WriteLine("\nWeapon: " + Weapon);
        }


    }
}

